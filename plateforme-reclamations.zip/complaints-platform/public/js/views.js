// public/js/views.js
const Views = (() => {
  const { esc, fmtDateTime, fmtDuration, statusPill, priorityPill, channelPill, categoryLabel,
    CHANNEL_LABELS, CATEGORY_LABELS, slaInfo, slaRingSvg, toast, openModal, closeModal, barList, debounce } = UI;

  function currentUser() { return Api.getUser(); }
  function isAgent() { return currentUser().role === 'agent'; }
  function isStaffPlus() { return currentUser().role === 'supervisor' || currentUser().role === 'admin'; }
  function isAdmin() { return currentUser().role === 'admin'; }

  function restricted(root, label) {
    root.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🔒</div>
      <div>Accès restreint : cette page nécessite le rôle superviseur ou admin.</div></div>`;
  }

  /* =====================================================
     TABLEAU DE BORD
  ===================================================== */
  const dashboard = {
    async render(root) {
      if (isAgent()) return dashboard.renderAgent(root);
      return dashboard.renderKpis(root, { restrictFilters: true });
    },

    async renderAgent(root) {
      root.innerHTML = `<div class="subtle">Chargement…</div>`;
      const tickets = await Api.get('/tickets');
      const active = tickets.filter((t) => t.current_status !== 'Resolved' && t.current_status !== 'Closed');
      const overdue = active.filter((t) => slaInfo(t).colorVar === '--red');
      const resolvedThisWeek = tickets.filter((t) => {
        if (!t.resolved_at) return false;
        return Date.now() - new Date(t.resolved_at).getTime() < 7 * 24 * 3600 * 1000;
      });
      const urgent = [...active].sort((a, b) => {
        const da = new Date(a.current_status === 'New' ? a.sla_first_response_due : a.sla_resolution_due);
        const db = new Date(b.current_status === 'New' ? b.sla_first_response_due : b.sla_resolution_due);
        return da - db;
      }).slice(0, 6);

      root.innerHTML = `
        <div class="grid grid-3" style="margin-bottom:22px;">
          <div class="card stat-card">
            <div class="stat-label">Mes tickets actifs</div>
            <div class="stat-value">${active.length}</div>
            <div class="stat-sub">Total assigné : ${tickets.length}</div>
          </div>
          <div class="card stat-card">
            <div class="stat-label">SLA dépassé</div>
            <div class="stat-value" style="color:${overdue.length ? 'var(--red)' : 'var(--ink-900)'}">${overdue.length}</div>
            <div class="stat-sub">Nécessite une action immédiate</div>
          </div>
          <div class="card stat-card">
            <div class="stat-label">Résolus cette semaine</div>
            <div class="stat-value">${resolvedThisWeek.length}</div>
            <div class="stat-sub">7 derniers jours</div>
          </div>
        </div>
        <div class="card card-pad">
          <div class="row-between" style="margin-bottom:14px;">
            <div class="section-title" style="margin:0;">Mes tickets les plus urgents</div>
            <a href="#/tickets" class="subtle">Voir tous mes tickets →</a>
          </div>
          <div id="urgent-list"></div>
        </div>`;
      document.getElementById('urgent-list').innerHTML = urgent.length
        ? ticketsTableHtml(urgent)
        : `<div class="empty-state">Aucun ticket actif. 🎉</div>`;
      wireTicketsTable(root);
    },

    async renderKpis(root, { restrictFilters } = {}) {
      if (!isStaffPlus()) return restricted(root);
      const channels = await Api.get('/channels').catch(() => []);
      root.innerHTML = `
        ${restrictFilters ? '' : filterBarHtml(channels)}
        <div id="kpi-cards" class="grid grid-4" style="margin-bottom:22px;"></div>
        <div class="grid grid-2">
          <div class="card card-pad">
            <div class="section-title">Volume par canal</div>
            <div id="vol-channel"></div>
          </div>
          <div class="card card-pad">
            <div class="section-title">Volume par catégorie</div>
            <div id="vol-category"></div>
          </div>
          <div class="card card-pad">
            <div class="section-title">Répartition par statut</div>
            <div id="vol-status"></div>
          </div>
          <div class="card card-pad">
            <div class="section-title">Répartition par priorité</div>
            <div id="vol-priority"></div>
          </div>
        </div>`;

      async function load() {
        const params = restrictFilters ? '' : readFilterParams(root);
        const kpis = await Api.get('/reports/kpis' + params);
        document.getElementById('kpi-cards').innerHTML = kpiCardsHtml(kpis);
        document.getElementById('vol-channel').innerHTML = barList(kpis.volume_by_channel, CHANNEL_LABELS);
        document.getElementById('vol-category').innerHTML = barList(kpis.volume_by_category, CATEGORY_LABELS);
        document.getElementById('vol-status').innerHTML = barList(kpis.volume_by_status, UI.STATUS_LABELS);
        document.getElementById('vol-priority').innerHTML = barList(kpis.volume_by_priority);
      }
      if (!restrictFilters) wireFilterBar(root, load);
      await load();
    },
  };

  function kpiCardsHtml(k) {
    const pct = (v) => (v === null || v === undefined ? '—' : `${Math.round(v * 100)}%`);
    return `
      <div class="card stat-card">
        <div class="stat-label">Tickets (période)</div>
        <div class="stat-value">${k.total_tickets}</div>
        <div class="stat-sub">${k.escalated_count} escaladé(s) automatiquement</div>
      </div>
      <div class="card stat-card">
        <div class="stat-label">MTTR moyen</div>
        <div class="stat-value">${k.mttr_hours === null ? '—' : k.mttr_hours.toFixed(1) + 'h'}</div>
        <div class="stat-sub">Création → résolution</div>
      </div>
      <div class="card stat-card">
        <div class="stat-label">Respect du SLA</div>
        <div class="stat-value" style="color:${k.sla_compliance_rate !== null && k.sla_compliance_rate < 0.8 ? 'var(--red)' : 'var(--ink-900)'}">${pct(k.sla_compliance_rate)}</div>
        <div class="stat-sub">Sur tickets résolus/clos</div>
      </div>
      <div class="card stat-card">
        <div class="stat-label">CSAT moyen</div>
        <div class="stat-value">${k.csat_average === null ? '—' : k.csat_average.toFixed(1) + ' / 5'}</div>
        <div class="stat-sub">${k.csat_responses} réponse(s)</div>
      </div>`;
  }

  function filterBarHtml(channels) {
    return `
      <div class="filter-bar card card-pad" style="margin-bottom:18px;">
        <label class="subtle">Du <input type="date" id="f-from" class="text-input" style="width:auto;display:inline-block;"></label>
        <label class="subtle">Au <input type="date" id="f-to" class="text-input" style="width:auto;display:inline-block;"></label>
        <select id="f-channel" class="text-input" style="width:auto;">
          <option value="">Tous les canaux</option>
          ${channels.map((c) => `<option value="${c.code}">${esc(c.label)}</option>`).join('')}
        </select>
        <select id="f-category" class="text-input" style="width:auto;">
          <option value="">Toutes les catégories</option>
          ${Object.entries(CATEGORY_LABELS).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}
        </select>
        <button id="f-apply" class="btn btn-primary btn-small">Appliquer</button>
        <button id="f-reset" class="btn btn-ghost btn-small">Réinitialiser</button>
      </div>`;
  }
  function readFilterParams(root) {
    const get = (id) => root.querySelector('#' + id)?.value;
    const params = new URLSearchParams();
    if (get('f-from')) params.set('from', get('f-from'));
    if (get('f-to')) params.set('to', get('f-to'));
    if (get('f-channel')) params.set('channel', get('f-channel'));
    if (get('f-category')) params.set('category', get('f-category'));
    const qs = params.toString();
    return qs ? '?' + qs : '';
  }
  function wireFilterBar(root, reload) {
    root.querySelector('#f-apply')?.addEventListener('click', reload);
    root.querySelector('#f-reset')?.addEventListener('click', () => {
      ['f-from', 'f-to', 'f-channel', 'f-category'].forEach((id) => {
        const el = root.querySelector('#' + id);
        if (el) el.value = '';
      });
      reload();
    });
  }

  /* =====================================================
     TICKETS — liste + détail
  ===================================================== */
  function ticketsTableHtml(tickets) {
    if (!tickets.length) return `<div class="empty-state"><div class="empty-state-icon">📭</div>Aucun ticket ne correspond à ces critères.</div>`;
    return `
      <div class="table-wrap"><table class="tickets-table">
        <thead><tr>
          <th>Ticket</th><th>Client</th><th>Canal</th><th>Catégorie</th><th>Priorité</th><th>Statut</th><th>Agent</th><th>SLA</th>
        </tr></thead>
        <tbody>
          ${tickets.map((t) => `
            <tr data-id="${t.ticket_id}">
              <td class="ticket-number">${esc(t.ticket_number)}</td>
              <td class="client-cell">
                <div class="name">${esc(t.client?.full_name || '—')}</div>
                <div class="sub">${esc(t.client?.is_vip ? 'Client VIP' : '')}</div>
              </td>
              <td>${channelPill(t.channel?.code)}</td>
              <td>${esc(categoryLabel(t.complaint?.category))}</td>
              <td>${priorityPill(t.priority)}</td>
              <td>${statusPill(t.current_status)}</td>
              <td>${esc(t.assigned_agent?.full_name || '—')}</td>
              <td>${slaRingSvg(t)}</td>
            </tr>`).join('')}
        </tbody>
      </table></div>`;
  }
  function wireTicketsTable(root) {
    root.querySelectorAll('table.tickets-table tbody tr').forEach((tr) => {
      tr.addEventListener('click', () => { location.hash = `#/tickets/${tr.dataset.id}`; });
    });
  }

  const tickets = {
    async render(root) {
      const channels = await Api.get('/channels').catch(() => []);
      root.innerHTML = `
        <div class="filter-bar">
          <input type="text" id="t-q" class="text-input search-input" placeholder="Rechercher : n° ticket, client, description…">
          <select id="t-status" class="text-input">
            <option value="">Tous statuts</option>
            ${Object.entries(UI.STATUS_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}
          </select>
          <select id="t-priority" class="text-input">
            <option value="">Toute priorité</option>
            <option value="P1">P1</option><option value="P2">P2</option><option value="P3">P3</option>
          </select>
          <select id="t-channel" class="text-input">
            <option value="">Tout canal</option>
            ${channels.map((c) => `<option value="${c.code}">${esc(c.label)}</option>`).join('')}
          </select>
        </div>
        <div id="tickets-table-root" class="card card-pad"></div>`;

      const load = debounce(async () => {
        const q = document.getElementById('t-q').value;
        const status = document.getElementById('t-status').value;
        const priority = document.getElementById('t-priority').value;
        const channel = document.getElementById('t-channel').value;
        const params = new URLSearchParams();
        if (q) params.set('q', q);
        if (status) params.set('status', status);
        if (priority) params.set('priority', priority);
        if (channel) params.set('channel', channel);
        const qs = params.toString();
        const list = await Api.get('/tickets' + (qs ? '?' + qs : ''));
        const tableRoot = document.getElementById('tickets-table-root');
        tableRoot.innerHTML = ticketsTableHtml(list);
        wireTicketsTable(tableRoot);
      }, 250);

      ['t-q'].forEach((id) => document.getElementById(id).addEventListener('input', load));
      ['t-status', 't-priority', 't-channel'].forEach((id) => document.getElementById(id).addEventListener('change', load));
      await load();
    },

    async renderDetail(root, id) {
      root.innerHTML = `<div class="subtle">Chargement du ticket…</div>`;
      let t;
      try {
        t = await Api.get(`/tickets/${id}`);
      } catch (e) {
        root.innerHTML = `<div class="empty-state">${esc(e.message)}</div>`;
        return;
      }
      const me = currentUser();
      const canAct = me.role !== 'agent' || t.assigned_agent?.user_id === me.user_id;
      const isTerminalClosed = t.current_status === 'Closed';

      root.innerHTML = `
        <a href="#/tickets" class="subtle">← Retour aux tickets</a>
        <div class="row-between" style="margin: 10px 0 18px;">
          <div>
            <div class="row gap-12">
              <span class="ticket-number" style="font-size:18px;">${esc(t.ticket_number)}</span>
              ${priorityPill(t.priority)} ${statusPill(t.current_status)} ${channelPill(t.channel?.code)}
            </div>
          </div>
          ${slaRingSvg(t)}
        </div>

        <div class="grid grid-2" style="align-items:start;">
          <div class="card card-pad" style="grid-column: span 1;">
            <div class="section-title">Réclamation</div>
            <dl class="kv-grid">
              <dt>Client</dt><dd>${esc(t.client?.full_name || '—')} ${t.client?.is_vip ? '<span class="pill pill-p2">VIP</span>' : ''}</dd>
              <dt>Contact</dt><dd>${esc(t.client?.email || t.client?.phone_number || '—')}</dd>
              <dt>N° compte</dt><dd>${esc(t.client?.account_number || '—')}</dd>
              <dt>Catégorie</dt><dd>${esc(categoryLabel(t.complaint?.category))}</dd>
              <dt>Créé le</dt><dd>${fmtDateTime(t.created_at)}</dd>
              <dt>Réf. externe</dt><dd>${esc(t.complaint?.external_reference_id || '—')}</dd>
            </dl>
            <div class="section-title" style="margin-top:16px;">Description</div>
            <p style="font-size:13.5px; color:var(--ink-700); white-space:pre-wrap;">${esc(t.complaint?.description || '—')}</p>
            ${t.priority_reasons?.length ? `
              <div class="section-title" style="margin-top:16px;">Pourquoi cette priorité ?</div>
              <ul style="margin:0; padding-left:18px; font-size:13px; color:var(--ink-600);">
                ${t.priority_reasons.map((r) => `<li>${esc(r)}</li>`).join('')}
              </ul>` : ''}
          </div>

          <div class="card card-pad">
            <div class="section-title">SLA</div>
            <dl class="kv-grid">
              <dt>Équipe</dt><dd>${esc(t.team || '—')}</dd>
              <dt>Agent assigné</dt><dd>${esc(t.assigned_agent?.full_name || '—')}</dd>
              <dt>1ère réponse due</dt><dd>${fmtDateTime(t.sla_first_response_due)}</dd>
              <dt>Résolution due</dt><dd>${fmtDateTime(t.sla_resolution_due)}</dd>
              <dt>Résolu le</dt><dd>${fmtDateTime(t.resolved_at)}</dd>
              <dt>Escaladé</dt><dd>${t.escalated ? 'Oui' : 'Non'}</dd>
            </dl>

            ${canAct ? `
            <div class="section-title" style="margin-top:18px;">Changer le statut</div>
            <div class="row gap-8" style="flex-wrap:wrap;">
              <select id="new-status" class="text-input" style="width:auto;" ${isTerminalClosed && me.role !== 'admin' ? 'disabled' : ''}>
                ${Object.entries(UI.STATUS_LABELS).map(([k, v]) => `<option value="${k}" ${k === t.current_status ? 'selected' : ''}>${v}</option>`).join('')}
              </select>
              <button id="status-apply" class="btn btn-primary btn-small" ${isTerminalClosed && me.role !== 'admin' ? 'disabled' : ''}>Appliquer</button>
            </div>
            <input type="text" id="status-comment" class="text-input" placeholder="Commentaire (optionnel)" style="margin-top:8px;">
            ` : `<div class="subtle" style="margin-top:18px;">Ce ticket n'est pas dans votre périmètre d'action.</div>`}

            ${isStaffPlus() ? `
            <div class="section-title" style="margin-top:18px;">Réassigner</div>
            <div class="row gap-8">
              <select id="reassign-agent" class="text-input" style="width:auto;"><option value="">Choisir un agent…</option></select>
              <button id="reassign-apply" class="btn btn-ghost btn-small">Réassigner</button>
            </div>` : ''}

            ${(t.current_status === 'Resolved' || t.current_status === 'Closed') ? `
            <div class="section-title" style="margin-top:18px;">Satisfaction client (démo)</div>
            <div class="row gap-8">
              <select id="csat-score" class="text-input" style="width:auto;">
                ${[5,4,3,2,1].map((n) => `<option value="${n}">${'★'.repeat(n)}${'☆'.repeat(5-n)}</option>`).join('')}
              </select>
              <button id="csat-apply" class="btn btn-ghost btn-small">Simuler la notation client</button>
            </div>` : ''}
          </div>
        </div>

        <div class="grid grid-2" style="margin-top:18px; align-items:start;">
          <div class="card card-pad">
            <div class="section-title">Historique des statuts</div>
            <div class="timeline">
              ${t.status_history.map((h) => `
                <div class="timeline-item">
                  <div class="timeline-dot"></div>
                  <div>
                    <div class="timeline-time">${fmtDateTime(h.changed_at)}</div>
                    <div class="timeline-text">${h.previous_status ? `${UI.STATUS_LABELS[h.previous_status]} → ${UI.STATUS_LABELS[h.new_status]}` : `Création (${UI.STATUS_LABELS[h.new_status]})`}${h.comment ? ` — ${esc(h.comment)}` : ''}</div>
                  </div>
                </div>`).join('')}
            </div>
          </div>
          <div class="card card-pad">
            <div class="section-title">Attributions</div>
            <div class="timeline">
              ${t.assignments_history.map((a) => `
                <div class="timeline-item">
                  <div class="timeline-dot"></div>
                  <div>
                    <div class="timeline-time">${fmtDateTime(a.assigned_at)}</div>
                    <div class="timeline-text">${esc(a.agent_name)} — <span class="subtle">${esc(a.reason || '')}</span>${a.unassigned_at ? ` <span class="subtle">(retiré le ${fmtDateTime(a.unassigned_at)})</span>` : ''}</div>
                  </div>
                </div>`).join('')}
            </div>
            <div class="section-title" style="margin-top:18px;">Notifications envoyées</div>
            <div class="timeline">
              ${t.notifications.map((n) => `
                <div class="timeline-item">
                  <div class="timeline-dot" style="background:var(--green)"></div>
                  <div>
                    <div class="timeline-time">${fmtDateTime(n.sent_at)} · ${esc(n.channel)} · ${esc(n.recipient_type)}</div>
                    <div class="timeline-text">${esc(n.message)}</div>
                  </div>
                </div>`).join('') || '<div class="subtle">Aucune notification.</div>'}
            </div>
          </div>
        </div>`;

      document.getElementById('status-apply')?.addEventListener('click', async () => {
        try {
          await Api.patch(`/tickets/${id}/status`, {
            new_status: document.getElementById('new-status').value,
            comment: document.getElementById('status-comment').value || undefined,
          });
          toast('Statut mis à jour.', 'success');
          tickets.renderDetail(root, id);
        } catch (e) { toast(e.message, 'error'); }
      });
      document.getElementById('csat-apply')?.addEventListener('click', async () => {
        try {
          await Api.post(`/tickets/${id}/csat`, { score: Number(document.getElementById('csat-score').value) });
          toast('Note client enregistrée (simulation).', 'success');
        } catch (e) { toast(e.message, 'error'); }
      });
      if (isStaffPlus()) {
        try {
          const users = await Api.get('/users');
          const agents = users.filter((u) => u.role === 'agent' && u.is_active);
          const sel = document.getElementById('reassign-agent');
          sel.innerHTML += agents.map((a) => `<option value="${a.user_id}">${esc(a.full_name)} — ${esc(a.team)} (${a.active_ticket_count} actifs)</option>`).join('');
          document.getElementById('reassign-apply').addEventListener('click', async () => {
            const agentId = sel.value;
            if (!agentId) return toast('Choisissez un agent.', 'error');
            try {
              await Api.post(`/tickets/${id}/reassign`, { agent_id: agentId, reason: 'Réassignation manuelle depuis la console.' });
              toast('Ticket réassigné.', 'success');
              tickets.renderDetail(root, id);
            } catch (e) { toast(e.message, 'error'); }
          });
        } catch (e) { /* silencieux si non autorisé */ }
      }
    },
  };

  /* =====================================================
     CLIENTS
  ===================================================== */
  const clients = {
    async render(root) {
      root.innerHTML = `
        <div class="filter-bar">
          <input type="text" id="c-q" class="text-input search-input" placeholder="Rechercher : nom, email, téléphone, n° compte…">
        </div>
        <div id="clients-table-root" class="card card-pad"></div>`;
      const load = debounce(async () => {
        const q = document.getElementById('c-q').value;
        const list = await Api.get('/clients' + (q ? `?q=${encodeURIComponent(q)}` : ''));
        renderTable(list);
      }, 250);
      document.getElementById('c-q').addEventListener('input', load);
      await load();

      function renderTable(list) {
        const root2 = document.getElementById('clients-table-root');
        if (!list.length) { root2.innerHTML = `<div class="empty-state">Aucun client trouvé.</div>`; return; }
        root2.innerHTML = `
          <div class="table-wrap"><table class="tickets-table">
            <thead><tr><th>Client</th><th>Email</th><th>Téléphone</th><th>N° compte</th><th>Statut</th></tr></thead>
            <tbody>
              ${list.map((c) => `
                <tr data-id="${c.client_id}">
                  <td class="client-cell"><div class="name">${esc(c.full_name)}</div></td>
                  <td>${esc(c.email || '—')}</td>
                  <td>${esc(c.phone_number || '—')}</td>
                  <td class="mono">${esc(c.account_number || '—')}</td>
                  <td>${c.is_vip ? '<span class="pill pill-p2">VIP</span>' : ''} ${c.is_verified ? '<span class="pill pill-resolved">Vérifié</span>' : '<span class="pill pill-new">À qualifier</span>'}</td>
                </tr>`).join('')}
            </tbody>
          </table></div>`;
        root2.querySelectorAll('tbody tr').forEach((tr) => {
          tr.addEventListener('click', () => { location.hash = `#/clients/${tr.dataset.id}`; });
        });
      }
    },

    async renderDetail(root, id) {
      root.innerHTML = `<div class="subtle">Chargement…</div>`;
      const c = await Api.get(`/clients/${id}`);
      root.innerHTML = `
        <a href="#/clients" class="subtle">← Retour aux clients</a>
        <div class="card card-pad" style="margin:14px 0 18px;">
          <div class="row-between">
            <div>
              <div class="section-title" style="margin-bottom:4px;">${esc(c.full_name)} ${c.is_vip ? '<span class="pill pill-p2">VIP</span>' : ''}</div>
              <div class="subtle">${esc(c.email || '')} ${c.phone_number ? ' · ' + esc(c.phone_number) : ''} ${c.account_number ? ' · ' + esc(c.account_number) : ''}</div>
            </div>
            <div class="subtle">Client depuis le ${fmtDateTime(c.created_at)}</div>
          </div>
        </div>
        <div class="section-title">Historique des réclamations (${c.tickets.length})</div>
        ${ticketsTableHtml(c.tickets)}`;
      wireTicketsTable(root);
    },
  };

  /* =====================================================
     SIMULATEUR DE CANAUX — cœur de la démonstration
  ===================================================== */
  const CHANNEL_TABS = [
    { code: 'email', label: 'Email' },
    { code: 'web', label: 'Portail Web' },
    { code: 'mobile_app', label: 'App Mobile' },
    { code: 'whatsapp', label: 'WhatsApp' },
    { code: 'facebook', label: 'Facebook' },
    { code: 'call_center', label: "Centre d'appels" },
    { code: 'agency', label: 'Agence' },
  ];

  function channelFormHtml(code) {
    switch (code) {
      case 'email':
        return `
          <div class="card card-pad email-mock">
            <div class="kv-grid" style="grid-template-columns:90px 1fr; margin-bottom:10px;">
              <dt>De :</dt><dd><input type="email" id="f-from" class="text-input" placeholder="client@example.com" required></dd>
              <dt>Objet :</dt><dd><input type="text" id="f-subject" class="text-input" placeholder="Problème avec ma facture"></dd>
            </div>
            <textarea id="f-body" class="text-input" rows="6" placeholder="Corps du message…" required></textarea>
          </div>`;
      case 'whatsapp':
      case 'facebook':
        return `
          <div class="card card-pad chat-mock">
            <div class="row gap-8" style="margin-bottom:10px;">
              <input type="text" id="${code === 'whatsapp' ? 'f-phone' : 'f-psid'}" class="text-input" placeholder="${code === 'whatsapp' ? 'Numéro WhatsApp (+212...)' : 'Identifiant conversation (PSID)'}" required>
              <input type="text" id="f-sender" class="text-input" placeholder="Nom affiché (optionnel)">
            </div>
            <div class="chat-bubble"><textarea id="f-message" class="text-input" rows="3" placeholder="Message du client…" required></textarea></div>
          </div>`;
      case 'web':
      case 'mobile_app':
        return `
          <div class="card card-pad ${code === 'mobile_app' ? 'phone-frame' : ''}">
            <div class="grid grid-2" style="margin-bottom:10px;">
              <input type="text" id="f-fullname" class="text-input" placeholder="Nom complet">
              <input type="text" id="f-identifier" class="text-input" placeholder="Email, téléphone ou n° de compte">
            </div>
            <select id="f-category" class="text-input" style="margin-bottom:10px;">
              <option value="">Catégorie (auto-détectée si vide)</option>
              ${Object.entries(CATEGORY_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}
            </select>
            <textarea id="f-description" class="text-input" rows="5" placeholder="Décrivez votre réclamation…" required></textarea>
          </div>`;
      case 'call_center':
        return `
          <div class="card card-pad cti-mock">
            <div class="row-between" style="margin-bottom:10px;">
              <span class="pill pill-channel">CTI — appel entrant</span>
              <span class="mono subtle" id="cti-number">+212 6XX-XXXXXX</span>
            </div>
            <div class="grid grid-2" style="margin-bottom:10px;">
              <input type="text" id="f-fullname" class="text-input" placeholder="Nom du client">
              <input type="text" id="f-identifier" class="text-input" placeholder="Email / n° compte (si différent)">
            </div>
            <textarea id="f-summary" class="text-input" rows="5" placeholder="Résumé de l'appel…" required></textarea>
          </div>`;
      case 'agency':
        return `
          <div class="card card-pad">
            <div class="grid grid-2" style="margin-bottom:10px;">
              <select id="f-agency-code" class="text-input">
                <option value="AG-CASA-01">Agence Casablanca Centre</option>
                <option value="AG-RABAT-02">Agence Rabat Agdal</option>
                <option value="AG-FES-03">Agence Fès Ville Nouvelle</option>
              </select>
              <input type="text" id="f-identifier" class="text-input" placeholder="N° de compte (recherche client)" required>
            </div>
            <input type="text" id="f-fullname" class="text-input" placeholder="Nom du client" style="margin-bottom:10px;">
            <textarea id="f-description" class="text-input" rows="5" placeholder="Description de la réclamation saisie par le conseiller…" required></textarea>
          </div>`;
      default:
        return '';
    }
  }

  function buildPayload(code) {
    const v = (id) => document.getElementById(id)?.value || undefined;
    switch (code) {
      case 'email': return { from: v('f-from'), subject: v('f-subject'), body: v('f-body') };
      case 'whatsapp': return { phone: v('f-phone'), sender_name: v('f-sender'), message: v('f-message') };
      case 'facebook': return { psid: v('f-psid'), sender_name: v('f-sender'), message: v('f-message') };
      case 'web': case 'mobile_app':
        return { full_name: v('f-fullname'), account_number: v('f-identifier'), category: v('f-category'), description: v('f-description') };
      case 'call_center':
        return { full_name: v('f-fullname'), account_number: v('f-identifier'), caller_number: document.getElementById('cti-number').textContent.trim(), summary: v('f-summary') };
      case 'agency':
        return { account_number: v('f-identifier'), full_name: v('f-fullname'), description: v('f-description'), agency_code: v('f-agency-code') };
      default: return {};
    }
  }

  function resultBannerHtml(res) {
    return `
      <div class="result-banner ok">
        <div class="row-between">
          <div>
            <div class="ticket-number" style="font-size:16px;">${esc(res.ticket.ticket_number)}</div>
            <div class="subtle" style="margin-top:2px;">Catégorie détectée : ${esc(categoryLabel(res.classification.category))}</div>
          </div>
          <div class="row gap-8">${priorityPill(res.ticket.priority)} ${statusPill(res.ticket.current_status)}</div>
        </div>
        <div class="kv-grid" style="margin-top:12px;">
          <dt>Équipe</dt><dd>${esc(res.team || '—')}</dd>
          <dt>Agent assigné</dt><dd>${esc(res.assigned_to || '—')}</dd>
        </div>
        ${res.priority.reasons.length ? `
          <div style="margin-top:10px;">
            <div class="subtle" style="margin-bottom:4px;">Logique de priorisation appliquée :</div>
            <ul style="margin:0; padding-left:18px; font-size:13px; color:var(--ink-700);">
              ${res.priority.reasons.map((r) => `<li>${esc(r)}</li>`).join('')}
            </ul>
          </div>` : ''}
        <div style="margin-top:12px;"><a href="#/tickets/${res.ticket.ticket_id}" class="btn btn-ghost btn-small">Ouvrir le ticket →</a></div>
      </div>`;
  }

  const simulator = {
    render(root) {
      let active = CHANNEL_TABS[0].code;
      root.innerHTML = `
        <div class="subtle" style="margin-bottom:14px; max-width:680px;">
          Simulez l'arrivée d'une réclamation depuis n'importe quel canal pour observer
          en direct la classification, le calcul de priorité, le SLA et l'attribution automatique.
        </div>
        <div class="tabs" id="sim-tabs">
          ${CHANNEL_TABS.map((c, i) => `<button class="tab-btn ${i === 0 ? 'active' : ''}" data-code="${c.code}">${c.label}</button>`).join('')}
        </div>
        <div id="sim-form-root"></div>
        <div id="sim-result-root"></div>`;

      function renderForm() {
        document.getElementById('sim-form-root').innerHTML = `
          ${channelFormHtml(active)}
          <div style="margin-top:14px;"><button id="sim-submit" class="btn btn-primary">Envoyer la réclamation simulée</button></div>`;
        if (active === 'call_center') {
          document.getElementById('cti-number').textContent = randomMoroccanPhone();
        }
        document.getElementById('sim-submit').addEventListener('click', async () => {
          const payload = buildPayload(active);
          try {
            const res = await Api.post(`/ingestion/${active}`, payload);
            document.getElementById('sim-result-root').innerHTML = resultBannerHtml(res);
            toast('Ticket créé avec succès.', 'success');
          } catch (e) {
            toast(e.message, 'error');
          }
        });
      }

      root.querySelectorAll('#sim-tabs .tab-btn').forEach((btn) => {
        btn.addEventListener('click', () => {
          active = btn.dataset.code;
          root.querySelectorAll('#sim-tabs .tab-btn').forEach((b) => b.classList.toggle('active', b === btn));
          document.getElementById('sim-result-root').innerHTML = '';
          renderForm();
        });
      });
      renderForm();
    },
  };
  function randomMoroccanPhone() {
    const n = Math.floor(100000 + Math.random() * 899999);
    return `+212 6${String(n).slice(0, 2)}-${String(n).slice(2)}`;
  }

  /* =====================================================
     ÉQUIPE (admin / superviseur)
  ===================================================== */
  const team = {
    async render(root) {
      if (!isStaffPlus()) return restricted(root);
      root.innerHTML = `<div class="subtle">Chargement de l'annuaire…</div>`;
      const users = await Api.get('/users');
      const byTeam = {};
      users.forEach((u) => { (byTeam[u.team || 'Sans équipe'] ||= []).push(u); });

      root.innerHTML = Object.entries(byTeam).map(([teamName, members]) => `
        <div class="card card-pad" style="margin-bottom:16px;">
          <div class="section-title">${esc(teamName)}</div>
          <div class="table-wrap"><table class="tickets-table">
            <thead><tr><th>Nom</th><th>Rôle</th><th>Email</th><th>Tickets actifs</th><th>Statut</th></tr></thead>
            <tbody>
              ${members.map((m) => `
                <tr>
                  <td class="client-cell"><div class="name">${esc(m.full_name)}</div></td>
                  <td>${esc(roleLabel(m.role))}</td>
                  <td>${esc(m.email)}</td>
                  <td class="mono">${m.active_ticket_count ?? '—'}</td>
                  <td>${m.is_active ? '<span class="pill pill-resolved">Actif</span>' : '<span class="pill pill-closed">Inactif</span>'}</td>
                </tr>`).join('')}
            </tbody>
          </table></div>
        </div>`).join('');
    },
  };
  function roleLabel(r) { return { agent: 'Agent', supervisor: 'Superviseur', admin: 'Admin' }[r] || r; }

  return { dashboard, tickets, clients, simulator, team, restricted };
})();
