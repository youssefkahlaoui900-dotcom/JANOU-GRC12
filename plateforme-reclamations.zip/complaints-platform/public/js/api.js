// public/js/api.js
const Api = (() => {
  const BASE = '/api';

  function token() {
    return localStorage.getItem('rc_token');
  }
  function setToken(t) {
    if (t) localStorage.setItem('rc_token', t);
    else localStorage.removeItem('rc_token');
  }
  function setUser(u) {
    if (u) localStorage.setItem('rc_user', JSON.stringify(u));
    else localStorage.removeItem('rc_user');
  }
  function getUser() {
    try {
      return JSON.parse(localStorage.getItem('rc_user'));
    } catch (e) {
      return null;
    }
  }

  async function request(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    const t = token();
    if (t) headers.Authorization = `Bearer ${t}`;
    const res = await fetch(BASE + path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try {
      data = await res.json();
    } catch (e) {
      data = null;
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Erreur HTTP ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  return {
    get: (path) => request('GET', path),
    post: (path, body) => request('POST', path, body),
    patch: (path, body) => request('PATCH', path, body),
    token,
    setToken,
    setUser,
    getUser,
    isLoggedIn: () => !!token(),
    logout: () => {
      setToken(null);
      setUser(null);
    },
  };
})();
