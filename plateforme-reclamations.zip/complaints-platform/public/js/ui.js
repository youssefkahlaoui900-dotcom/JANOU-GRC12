// public/js/ui.js
const UI = (() => {
  function esc(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function fmtDateTime(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  function fmtDuration(ms) {
    const abs = Math.abs(ms);
    const totalMin = Math.round(abs / 60000);
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (h <= 0) return `${m}min`;
    return `${h}h${m > 0 ? ' ' + m + 'min' : ''}`;
  }

  const STATUS_LABELS = {
    New: 'Nouveau',
    'In Progress': 'En cours',
    Pending: 'En attente',
    Resolved: 'Résolu',
    Closed: 'Clôturé',
  };
  const STATUS_CLASS = {
    New: 'pill-new',
    'In Progress': 'pill-inprogress',
    Pending: 'pill-pending',
    Resolved: 'pill-resolved',
    Closed: 'pill-closed',
  };

  function statusPill(status) {
    return `<span class="pill ${STATUS_CLASS[status] || 'pill-new'}">${STATUS_LABELS[status] || status}</span>`;
  }
  function priorityPill(priority) {
    return `<span class="pill pill-${(priority || '').toLowerCase()}">${esc(priority)}</span>`;
  }
  const CHANNEL_LABELS = {
    email: 'Email', web: 'Portail Web', mobile_app: 'App Mobile', call_center: 'Centre d\'appels',
    facebook: 'Facebook', whatsapp: 'WhatsApp', agency: 'Agence',
  };
  function channelPill(code) {
    return `<span class="pill pill-channel">${CHANNEL_LABELS[code] || esc(code)}</span>`;
  }
  const CATEGORY_LABELS = {
    facturation: 'Facturation', livraison: 'Livraison', technique: 'Technique',
    fraude_securite: 'Sécurité & Fraude', autre: 'Autre',
  };
  function categoryLabel(code) {
    return CATEGORY_LABELS[code] || code || '—';
  }

  // --- Anneau SLA : élément signature du tableau de bord opérationnel ---
  function slaInfo(ticket) {
    const now = Date.now();
    const isTerminal = ticket.current_status === 'Resolved' || ticket.current_status === 'Closed';
    if (isTerminal) {
      const resolvedAt = ticket.resolved_at ? new Date(ticket.resolved_at).getTime() : now;
      const due = new Date(ticket.sla_resolution_due).getTime();
      const met = resolvedAt <= due;
      return { terminal: true, met, label: met ? 'SLA respecté' : 'SLA dépassé', colorVar: met ? '--green' : '--red' };
    }
    const isNew = ticket.current_status === 'New';
    const deadline = new Date(isNew ? ticket.sla_first_response_due : ticket.sla_resolution_due).getTime();
    const created = new Date(ticket.created_at).getTime();
    const total = Math.max(deadline - created, 1);
    const elapsed = now - created;
    const pct = Math.min(Math.max(elapsed / total, 0), 1);
    const remaining = deadline - now;
    let colorVar = '--green';
    if (remaining < 0) colorVar = '--red';
    else if (remaining < total * 0.2) colorVar = '--amber';
    const label = remaining < 0 ? `Dépassé de ${fmtDuration(remaining)}` : `${fmtDuration(remaining)} restant`;
    return { terminal: false, pct, label, colorVar, isNew };
  }

  function slaRingSvg(ticket) {
    const info = slaInfo(ticket);
    const r = 13;
    const c = 2 * Math.PI * r;
    if (info.terminal) {
      const color = `var(${info.colorVar})`;
      const symbol = info.met ? '✓' : '✕';
      return `
        <div class="sla-ring-wrap" title="${esc(info.label)}">
          <svg width="32" height="32" viewBox="0 0 32 32">
            <circle cx="16" cy="16" r="${r}" fill="none" stroke="${color}" stroke-width="3" opacity="0.18"></circle>
            <text x="16" y="20.5" text-anchor="middle" font-size="13" fill="${color}" font-family="var(--font-display)">${symbol}</text>
          </svg>
          <span class="sla-ring-label" style="color:${color}">${esc(info.label)}</span>
        </div>`;
    }
    const offset = c * (1 - info.pct);
    const color = `var(${info.colorVar})`;
    return `
      <div class="sla-ring-wrap" title="${esc(info.label)}">
        <svg width="32" height="32" viewBox="0 0 32 32" style="transform:rotate(-90deg)">
          <circle cx="16" cy="16" r="${r}" fill="none" stroke="var(--slate-soft)" stroke-width="3"></circle>
          <circle cx="16" cy="16" r="${r}" fill="none" stroke="${color}" stroke-width="3"
            stroke-dasharray="${c.toFixed(2)}" stroke-dashoffset="${offset.toFixed(2)}" stroke-linecap="round"></circle>
        </svg>
        <span class="sla-ring-label" style="color:${color}">${esc(info.label)}</span>
      </div>`;
  }

  // --- Toasts ---
  function toast(message, type) {
    const root = document.getElementById('toast-root');
    const el = document.createElement('div');
    el.className = `toast ${type || ''}`.trim();
    el.textContent = message;
    root.appendChild(el);
    setTimeout(() => el.remove(), 3800);
  }

  // --- Modal ---
  function openModal(innerHtml, onMount) {
    const root = document.getElementById('modal-root');
    root.innerHTML = `
      <div class="modal-backdrop" id="modal-backdrop">
        <div class="modal-panel">${innerHtml}</div>
      </div>`;
    document.getElementById('modal-backdrop').addEventListener('click', (e) => {
      if (e.target.id === 'modal-backdrop') closeModal();
    });
    if (onMount) onMount(root);
  }
  function closeModal() {
    document.getElementById('modal-root').innerHTML = '';
  }

  // --- Liste à barres (volumes par canal / statut / priorité / catégorie) ---
  function barList(dataObj, labelMap) {
    const entries = Object.entries(dataObj || {});
    if (!entries.length) return `<div class="subtle">Aucune donnée pour cette période.</div>`;
    const max = Math.max(...entries.map(([, v]) => v), 1);
    return `<div class="bar-list">${entries
      .sort((a, b) => b[1] - a[1])
      .map(
        ([k, v]) => `
        <div class="bar-row">
          <div class="bar-label">${esc((labelMap && labelMap[k]) || k)}</div>
          <div class="bar-track"><div class="bar-fill" style="width:${(v / max) * 100}%"></div></div>
          <div class="bar-value">${v}</div>
        </div>`
      )
      .join('')}</div>`;
  }

  function debounce(fn, ms) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  }

  return {
    esc, fmtDateTime, fmtDuration, statusPill, priorityPill, channelPill, categoryLabel,
    CHANNEL_LABELS, CATEGORY_LABELS, STATUS_LABELS,
    slaInfo, slaRingSvg, toast, openModal, closeModal, barList, debounce,
  };
})();
