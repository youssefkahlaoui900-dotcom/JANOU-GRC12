// public/js/app.js
(() => {
  const DEMO_ACCOUNTS = [
    { email: 'admin@demo.local', role: 'Admin', name: 'Amine Tazi' },
    { email: 'superviseur1@demo.local', role: 'Superviseur', name: 'Sara El Idrissi (Support Général)' },
    { email: 'superviseur2@demo.local', role: 'Superviseur', name: 'Karim Benali (Technique)' },
    { email: 'agent.facturation@demo.local', role: 'Agent', name: 'Yasmine Cherkaoui (Facturation)' },
    { email: 'agent.technique@demo.local', role: 'Agent', name: 'Nadia Bensaid (Technique)' },
    { email: 'agent.livraison@demo.local', role: 'Agent', name: 'Salma Ouahbi (Livraison)' },
    { email: 'agent.securite@demo.local', role: 'Agent', name: 'Imane Zahidi (Sécurité & Fraude)' },
    { email: 'agent.general@demo.local', role: 'Agent', name: 'Reda Lahlou (Support Général)' },
  ];
  const DEMO_PASSWORD = 'Demo1234!';

  const ROUTES = {
    dashboard: { title: 'Tableau de bord', render: (root) => Views.dashboard.render(root) },
    tickets: {
      title: 'Tickets',
      render: (root, params) => (params[0] ? Views.tickets.renderDetail(root, params[0]) : Views.tickets.render(root)),
    },
    clients: {
      title: 'Clients',
      render: (root, params) => (params[0] ? Views.clients.renderDetail(root, params[0]) : Views.clients.render(root)),
    },
    simulator: { title: 'Simulateur de canaux', render: (root) => Views.simulator.render(root) },
    reports: { title: 'Rapports', render: (root) => Views.dashboard.renderKpis(root, { restrictFilters: false }) },
    admin: { title: 'Équipe', render: (root) => Views.team.render(root) },
  };

  function renderDemoAccounts() {
    const root = document.getElementById('demo-accounts');
    root.innerHTML = DEMO_ACCOUNTS.map(
      (a) => `<button type="button" class="demo-account-btn" data-email="${a.email}">${a.name} <span class="role-tag">${a.role}</span></button>`
    ).join('');
    root.querySelectorAll('.demo-account-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.getElementById('login-email').value = btn.dataset.email;
        document.getElementById('login-password').value = DEMO_PASSWORD;
      });
    });
  }

  function showLogin() {
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('app-shell').classList.add('hidden');
  }
  function showApp() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app-shell').classList.remove('hidden');
    renderUserChip();
    renderNavVisibility();
  }

  function renderUserChip() {
    const u = Api.getUser();
    if (!u) return;
    document.getElementById('user-chip').innerHTML = `<b>${UI.esc(u.full_name)}</b> · ${UI.esc(roleLabel(u.role))}${u.team ? ' · ' + UI.esc(u.team) : ''}`;
  }
  function roleLabel(r) { return { agent: 'Agent', supervisor: 'Superviseur', admin: 'Admin' }[r] || r; }

  function renderNavVisibility() {
    const u = Api.getUser();
    const restrictedToStaff = u.role === 'agent';
    document.querySelectorAll('.nav-restricted').forEach((el) => {
      el.classList.toggle('hidden', restrictedToStaff);
    });
  }

  function parseHash() {
    const raw = (location.hash || '#/dashboard').replace(/^#\/?/, '');
    const [route, ...params] = raw.split('/').filter(Boolean);
    return { route: route || 'dashboard', params };
  }

  async function router() {
    if (!Api.isLoggedIn()) { showLogin(); return; }
    showApp();
    const { route, params } = parseHash();
    const conf = ROUTES[route] || ROUTES.dashboard;
    document.querySelectorAll('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.route === route));
    document.getElementById('topbar-title').textContent = conf.title;
    const viewRoot = document.getElementById('view-root');
    viewRoot.innerHTML = `<div class="subtle">Chargement…</div>`;
    try {
      await conf.render(viewRoot, params);
    } catch (e) {
      viewRoot.innerHTML = `<div class="empty-state">${UI.esc(e.message || 'Une erreur est survenue.')}</div>`;
    }
  }

  function wireLogin() {
    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;
      const errEl = document.getElementById('login-error');
      errEl.classList.add('hidden');
      try {
        const { token, user } = await Api.post('/auth/login', { email, password });
        Api.setToken(token);
        Api.setUser(user);
        location.hash = '#/dashboard';
        router();
      } catch (e2) {
        errEl.textContent = e2.message;
        errEl.classList.remove('hidden');
      }
    });
  }

  function wireLogout() {
    document.getElementById('logout-btn').addEventListener('click', () => {
      Api.logout();
      location.hash = '#/dashboard';
      showLogin();
    });
  }

  window.addEventListener('hashchange', router);
  document.addEventListener('DOMContentLoaded', () => {
    renderDemoAccounts();
    wireLogin();
    wireLogout();
    router();
  });
})();
