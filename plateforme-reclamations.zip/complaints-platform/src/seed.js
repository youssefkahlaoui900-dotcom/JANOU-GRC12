// src/seed.js
const bcrypt = require('bcryptjs');
const Store = require('./db');

const DEMO_PASSWORD = 'Demo1234!';

function seedIfEmpty() {
  if (Store.all('users').length > 0) return false;

  const passwordHash = bcrypt.hashSync(DEMO_PASSWORD, 10);
  const now = new Date().toISOString();

  // --- Équipes ---
  const teamDefs = ['Support Général', 'Facturation', 'Technique', 'Livraison', 'Sécurité & Fraude'];
  const teams = teamDefs.map((name) => ({ team_id: Store.uuid(), name }));
  teams.forEach((t) => Store.insert('teams', t));
  const teamByName = (name) => teams.find((t) => t.name === name);

  // --- Canaux ---
  const channelDefs = [
    ['email', 'Email'],
    ['web', 'Portail Web'],
    ['mobile_app', 'Application Mobile'],
    ['call_center', 'Centre d\'appels'],
    ['facebook', 'Facebook Messenger'],
    ['whatsapp', 'WhatsApp Business'],
    ['agency', 'Agence physique'],
  ];
  channelDefs.forEach(([code, label]) =>
    Store.insert('channels', { channel_id: Store.uuid(), code, label, is_active: true })
  );

  // --- Utilisateurs ---
  const users = [
    { full_name: 'Amine Tazi', email: 'admin@demo.local', role: 'admin', team: 'Support Général' },
    { full_name: 'Sara El Idrissi', email: 'superviseur1@demo.local', role: 'supervisor', team: 'Support Général' },
    { full_name: 'Karim Benali', email: 'superviseur2@demo.local', role: 'supervisor', team: 'Technique' },
    { full_name: 'Yasmine Cherkaoui', email: 'agent.facturation@demo.local', role: 'agent', team: 'Facturation' },
    { full_name: 'Omar Fassi', email: 'agent.facturation2@demo.local', role: 'agent', team: 'Facturation' },
    { full_name: 'Nadia Bensaid', email: 'agent.technique@demo.local', role: 'agent', team: 'Technique' },
    { full_name: 'Hicham Alaoui', email: 'agent.technique2@demo.local', role: 'agent', team: 'Technique' },
    { full_name: 'Salma Ouahbi', email: 'agent.livraison@demo.local', role: 'agent', team: 'Livraison' },
    { full_name: 'Reda Lahlou', email: 'agent.general@demo.local', role: 'agent', team: 'Support Général' },
    { full_name: 'Imane Zahidi', email: 'agent.securite@demo.local', role: 'agent', team: 'Sécurité & Fraude' },
  ];
  users.forEach((u) =>
    Store.insert('users', {
      user_id: Store.uuid(),
      full_name: u.full_name,
      email: u.email,
      password_hash: passwordHash,
      role: u.role,
      team_id: teamByName(u.team).team_id,
      is_active: true,
      created_at: now,
    })
  );

  // --- Clients de démonstration ---
  const clients = [
    { full_name: 'Yassine Berrada', email: 'yassine.berrada@example.com', phone_number: '+212600111222', account_number: 'ACC-10021', is_vip: true },
    { full_name: 'Fatima Zahra Idrissi', email: 'fz.idrissi@example.com', phone_number: '+212600333444', account_number: 'ACC-10022', is_vip: false },
    { full_name: 'Mehdi Kabbaj', email: 'mehdi.kabbaj@example.com', phone_number: '+212600555666', account_number: 'ACC-10023', is_vip: false },
  ];
  clients.forEach((c) =>
    Store.insert('clients', {
      client_id: Store.uuid(),
      full_name: c.full_name,
      email: c.email,
      phone_number: c.phone_number,
      account_number: c.account_number,
      social_psid: null,
      is_verified: true,
      is_vip: c.is_vip,
      created_at: now,
    })
  );

  return true;
}

module.exports = { seedIfEmpty, DEMO_PASSWORD };
