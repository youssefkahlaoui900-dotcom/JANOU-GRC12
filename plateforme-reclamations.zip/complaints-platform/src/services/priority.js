// src/services/priority.js
// Calcule la priorité à la création du ticket en combinant : catégorie,
// mots-clés sensibles, ampleur de l'impact, statut VIP du client et canal
// d'origine — conformément à la section 3.3 de la spécification.

const CATEGORY_WEIGHT = {
  fraude_securite: 80,
  technique: 30,
  livraison: 15,
  facturation: 15,
  autre: 5,
};

const CHANNEL_WEIGHT = {
  call_center: 10,
  agency: 5,
  email: 0,
  web: 0,
  mobile_app: 0,
  facebook: 0,
  whatsapp: 0,
};

function computePriority({ classification, client, channel }) {
  let score = 0;
  const reasons = [];

  if (classification.sensitive) {
    score += 100;
    reasons.push('Mot-clé sensible détecté (fraude/sécurité)');
  }

  score += CATEGORY_WEIGHT[classification.category] || 0;

  if (classification.widespreadImpact) {
    score += 40;
    reasons.push('Impact étendu probable (plusieurs clients / service indisponible)');
  }

  if (client && client.is_vip) {
    score += 20;
    reasons.push('Client VIP');
  }

  if (client && (client.complaints_last_90_days || 0) >= 3) {
    score += 10;
    reasons.push('Client récidiviste (≥3 réclamations / 90 jours)');
  }

  score += CHANNEL_WEIGHT[channel] || 0;

  let priority = 'P3';
  if (score >= 80) priority = 'P1';
  else if (score >= 30) priority = 'P2';

  return { priority, score, reasons };
}

const SLA_HOURS = {
  P1: { firstResponse: 1, resolution: 4 },
  P2: { firstResponse: 4, resolution: 24 },
  P3: { firstResponse: 24, resolution: 72 },
};

module.exports = { computePriority, SLA_HOURS, CATEGORY_WEIGHT, CHANNEL_WEIGHT };
