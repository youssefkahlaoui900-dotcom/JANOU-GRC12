// src/services/ticketNumber.js
const Store = require('../db');

function generateTicketNumber(date = new Date()) {
  const year = date.getFullYear();
  const seq = Store.nextTicketSequence(String(year));
  return `TCK-${year}-${String(seq).padStart(6, '0')}`;
}

module.exports = { generateTicketNumber };
