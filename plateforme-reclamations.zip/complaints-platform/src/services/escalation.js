// src/services/escalation.js
const Store = require('../db');
const { reassign } = require('./assignment');
const notifications = require('./notifications');

function teamNameOf(teamId) {
  const team = Store.get('teams', teamId, 'team_id');
  return team ? team.name : null;
}

function pickSupervisor(teamName) {
  const candidates = Store.find(
    'users',
    (u) => u.role === 'supervisor' && u.is_active && teamNameOf(u.team_id) === teamName
  );
  if (candidates.length) return candidates[0];
  return Store.findOne('users', (u) => u.role === 'supervisor' && u.is_active);
}

function checkSlaEscalations() {
  const now = Date.now();
  const overdue = Store.all('tickets').filter(
    (t) =>
      !t.escalated &&
      t.current_status === 'New' &&
      new Date(t.sla_first_response_due).getTime() < now
  );

  for (const ticket of overdue) {
    const supervisor = pickSupervisor(ticket.team);
    if (!supervisor) continue;

    reassign(ticket.ticket_id, supervisor.user_id, null, 'Escalade automatique : SLA de première réponse dépassé.');
    Store.update('tickets', ticket.ticket_id, 'ticket_id', { escalated: true });
    Store.insert('status_history', {
      history_id: Store.uuid(),
      ticket_id: ticket.ticket_id,
      previous_status: ticket.current_status,
      new_status: ticket.current_status,
      changed_by: null,
      changed_at: new Date().toISOString(),
      comment: 'Escalade automatique : SLA de première réponse dépassé, réattribué à un superviseur.',
    });
    notifications.send(ticket.ticket_id, 'agent', supervisor.user_id, 'in_app', 'escalade', {
      ticket_number: ticket.ticket_number,
    });
  }
  return overdue.length;
}

module.exports = { checkSlaEscalations };
