// src/services/assignment.js
// Attribution automatique : routage par compétence (catégorie -> équipe) puis
// sélection de l'agent le moins chargé de cette équipe (nombre de tickets
// actifs assignés). Conserve l'historique complet dans `assignments`
// (jamais d'écrasement), conformément à la section 3.4.

const Store = require('../db');

const CATEGORY_TEAM = {
  facturation: 'Facturation',
  livraison: 'Livraison',
  technique: 'Technique',
  fraude_securite: 'Sécurité & Fraude',
  autre: 'Support Général',
};

const ACTIVE_STATUSES = ['New', 'In Progress', 'Pending'];

function activeAssignmentCount(agentId) {
  const activeTicketIds = new Set(
    Store.all('tickets')
      .filter((t) => ACTIVE_STATUSES.includes(t.current_status))
      .map((t) => t.ticket_id)
  );
  return Store.all('assignments').filter(
    (a) => a.agent_id === agentId && a.unassigned_at === null && activeTicketIds.has(a.ticket_id)
  ).length;
}

function teamForCategory(category) {
  return CATEGORY_TEAM[category] || 'Support Général';
}

function pickAgentForTeam(teamName) {
  const team = Store.findOne('teams', (t) => t.name === teamName);
  let candidates = [];
  if (team) {
    candidates = Store.find(
      'users',
      (u) => u.team_id === team.team_id && u.role === 'agent' && u.is_active
    );
  }
  // Repli : si aucun agent actif dans l'équipe cible, élargir à tous les agents actifs
  if (candidates.length === 0) {
    candidates = Store.find('users', (u) => u.role === 'agent' && u.is_active);
  }
  if (candidates.length === 0) return null;

  let best = candidates[0];
  let bestLoad = activeAssignmentCount(best.user_id);
  for (const c of candidates.slice(1)) {
    const load = activeAssignmentCount(c.user_id);
    if (load < bestLoad) {
      best = c;
      bestLoad = load;
    }
  }
  return best;
}

function autoAssign(ticketId, category) {
  const teamName = teamForCategory(category);
  const agent = pickAgentForTeam(teamName);
  if (!agent) return null;

  const assignment = {
    assignment_id: Store.uuid(),
    ticket_id: ticketId,
    agent_id: agent.user_id,
    assigned_by: null, // null = automatique
    assigned_at: new Date().toISOString(),
    unassigned_at: null,
    reason: 'Attribution automatique (routage par compétence + charge)',
  };
  Store.insert('assignments', assignment);
  return { agent, assignment, teamName };
}

function reassign(ticketId, newAgentId, assignedByUserId, reason) {
  const previous = Store.findOne(
    'assignments',
    (a) => a.ticket_id === ticketId && a.unassigned_at === null
  );
  if (previous) {
    Store.update('assignments', previous.assignment_id, 'assignment_id', {
      unassigned_at: new Date().toISOString(),
    });
  }
  const assignment = {
    assignment_id: Store.uuid(),
    ticket_id: ticketId,
    agent_id: newAgentId,
    assigned_by: assignedByUserId,
    assigned_at: new Date().toISOString(),
    unassigned_at: null,
    reason: reason || 'Réassignation manuelle',
  };
  Store.insert('assignments', assignment);
  return assignment;
}

module.exports = { autoAssign, reassign, teamForCategory, activeAssignmentCount, CATEGORY_TEAM };
