// src/services/classify.js
// Pré-catégorisation légère par mots-clés, jouant le rôle du "modèle NLP
// léger" décrit en section 2.1 de la spécification. Suffisant pour un
// prototype ; remplaçable par un vrai modèle NLP sans changer l'interface
// (classify(text) -> { category, sensitive, matchedKeywords }).

const KEYWORD_MAP = {
  fraude_securite: [
    'fraude', 'frauduleuse', 'piraté', 'piratage', 'pirater', 'vol', 'volé',
    'accès non autorisé', 'compte bloqué', 'bloqué mon compte', 'usurpation',
    'sécurité compromise', 'transaction non reconnue', 'hacker',
  ],
  technique: [
    'bug', 'panne', 'erreur', 'ne fonctionne pas', 'application', 'site web',
    'connexion impossible', 'service indisponible', 'plantage', 'écran blanc',
    'mot de passe', 'lenteur',
  ],
  livraison: [
    'livraison', 'colis', 'retard de livraison', 'expédition', 'transporteur',
    'commande non reçue', 'colis perdu', 'livreur', 'point relais',
  ],
  facturation: [
    'facture', 'facturation', 'paiement', 'prélèvement', 'remboursement',
    'montant', 'frais', 'tarif', 'abonnement', 'double prélèvement', 'trop perçu',
  ],
};

const WIDESPREAD_IMPACT_KEYWORDS = [
  'indisponible', 'panne générale', 'plusieurs clients', 'tout le monde',
  'national', 'depuis ce matin', 'depuis hier',
];

function normalize(text) {
  return (text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, ''); // retire les accents pour un matching robuste
}

function classify(text) {
  const norm = normalize(text);
  const matched = { category: 'autre', sensitive: false, matchedKeywords: [], widespreadImpact: false };
  let bestCategory = 'autre';
  let bestScore = 0;

  for (const [category, keywords] of Object.entries(KEYWORD_MAP)) {
    let score = 0;
    const hits = [];
    for (const kw of keywords) {
      if (norm.includes(normalize(kw))) {
        score += 1;
        hits.push(kw);
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestCategory = category;
      matched.matchedKeywords = hits;
    }
  }

  matched.category = bestCategory;
  matched.sensitive = bestCategory === 'fraude_securite' && bestScore > 0;
  matched.widespreadImpact = WIDESPREAD_IMPACT_KEYWORDS.some((kw) => norm.includes(normalize(kw)));

  return matched;
}

module.exports = { classify, KEYWORD_MAP };
