// src/services/sla.js
const { SLA_HOURS } = require('./priority');

function addHours(date, hours) {
  return new Date(date.getTime() + hours * 60 * 60 * 1000);
}

function computeSlaDueDates(priority, createdAt) {
  const created = new Date(createdAt);
  const conf = SLA_HOURS[priority];
  return {
    sla_first_response_due: addHours(created, conf.firstResponse).toISOString(),
    sla_resolution_due: addHours(created, conf.resolution).toISOString(),
  };
}

module.exports = { computeSlaDueDates };
