// src/services/enrich.js
const Store = require('../db');

function currentAssignment(ticketId) {
  return Store.findOne(
    'assignments',
    (a) => a.ticket_id === ticketId && a.unassigned_at === null
  );
}

function enrichTicket(ticket) {
  const complaint = Store.get('complaints', ticket.complaint_id, 'complaint_id');
  const client = complaint ? Store.get('clients', complaint.client_id, 'client_id') : null;
  const channel = complaint ? Store.get('channels', complaint.channel_id, 'channel_id') : null;
  const assignment = currentAssignment(ticket.ticket_id);
  const agent = assignment ? Store.get('users', assignment.agent_id, 'user_id') : null;

  return {
    ...ticket,
    complaint: complaint
      ? {
          complaint_id: complaint.complaint_id,
          category: complaint.category,
          description: complaint.description,
          attachments: complaint.attachments,
          external_reference_id: complaint.external_reference_id,
          created_at: complaint.created_at,
        }
      : null,
    client: client
      ? {
          client_id: client.client_id,
          full_name: client.full_name,
          email: client.email,
          phone_number: client.phone_number,
          account_number: client.account_number,
          is_vip: client.is_vip,
        }
      : null,
    channel: channel ? { code: channel.code, label: channel.label } : null,
    assigned_agent: agent ? { user_id: agent.user_id, full_name: agent.full_name } : null,
  };
}

function ticketHistory(ticketId) {
  return Store.find('status_history', (h) => h.ticket_id === ticketId).sort(
    (a, b) => new Date(a.changed_at) - new Date(b.changed_at)
  );
}

function ticketAssignments(ticketId) {
  return Store.find('assignments', (a) => a.ticket_id === ticketId).sort(
    (a, b) => new Date(a.assigned_at) - new Date(b.assigned_at)
  );
}

function ticketNotifications(ticketId) {
  return Store.find('notifications', (n) => n.ticket_id === ticketId).sort(
    (a, b) => new Date(a.sent_at) - new Date(b.sent_at)
  );
}

module.exports = { enrichTicket, currentAssignment, ticketHistory, ticketAssignments, ticketNotifications };
