// src/services/notifications.js
// Simule l'envoi via les fournisseurs externes (SES/Twilio/FCM) décrits en
// section 7. Aucun appel réseau réel n'est effectué ; chaque notification
// est journalisée dans la table `notifications` pour preuve d'envoi et KPI,
// conformément à la section 4.8 / 6.

const Store = require('../db');

const TEMPLATES = {
  accuse_reception: (ctx) =>
    `Bonjour, votre réclamation a été enregistrée sous le numéro ${ctx.ticket_number}. Nous reviendrons vers vous sous peu.`,
  nouvelle_attribution: (ctx) =>
    `Nouveau ticket assigné : ${ctx.ticket_number} (priorité ${ctx.priority}).`,
  changement_statut: (ctx) =>
    `Le statut de votre réclamation ${ctx.ticket_number} est passé à "${ctx.new_status}".`,
  escalade: (ctx) =>
    `Ticket ${ctx.ticket_number} escaladé : SLA de première réponse dépassé.`,
};

function send(ticketId, recipientType, recipientId, channel, templateKey, ctx) {
  const message = TEMPLATES[templateKey] ? TEMPLATES[templateKey](ctx) : templateKey;
  const notification = {
    notification_id: Store.uuid(),
    ticket_id: ticketId,
    recipient_type: recipientType,
    recipient_id: recipientId,
    channel,
    status: 'sent', // simulation : toujours réussi dans ce prototype
    message,
    sent_at: new Date().toISOString(),
  };
  Store.insert('notifications', notification);
  return notification;
}

module.exports = { send };
