// src/services/pipeline.js
// Implémente le flux décrit en section 1.3 :
//   objet pivot -> résolution client -> classification -> création
//   Complaint -> création Ticket (priorité + SLA) -> attribution -> notif.
// C'est le seul point d'entrée du "Service Réclamations (Core)" : quel que
// soit le canal d'origine, il ne consomme que l'objet pivot normalisé
// (section 2.6) et ne connaît jamais le format natif d'un canal.

const Store = require('../db');
const { classify } = require('./classify');
const { computePriority } = require('./priority');
const { computeSlaDueDates } = require('./sla');
const { generateTicketNumber } = require('./ticketNumber');
const { autoAssign } = require('./assignment');
const notifications = require('./notifications');

function countRecentComplaints(clientId, days = 90) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return Store.find(
    'complaints',
    (c) => c.client_id === clientId && new Date(c.created_at).getTime() >= cutoff
  ).length;
}

function findOrCreateClient({ channel, identifier, hintName }) {
  if (identifier) {
    const existing = Store.findOne(
      'clients',
      (c) =>
        (c.email && c.email === identifier) ||
        (c.phone_number && c.phone_number === identifier) ||
        (c.account_number && c.account_number === identifier) ||
        (c.social_psid && c.social_psid === identifier)
    );
    if (existing) return existing;
  }

  const isEmail = !!identifier && identifier.includes('@');
  const client = {
    client_id: Store.uuid(),
    full_name: hintName || 'Client à qualifier',
    email: isEmail ? identifier : null,
    phone_number: !isEmail && channel !== 'facebook' ? identifier || null : null,
    account_number: null,
    social_psid: channel === 'facebook' ? identifier || null : null,
    is_verified: false,
    is_vip: false,
    created_at: new Date().toISOString(),
  };
  Store.insert('clients', client);
  return client;
}

/**
 * @param {Object} pivot - Objet pivot normalisé (section 2.6)
 *   channel, external_reference_id, client_identifier, client_hint_name,
 *   raw_content, attachments[], metadata{}, explicit_client_id, created_by
 */
function processIncoming(pivot) {
  const channelRecord = Store.findOne('channels', (c) => c.code === pivot.channel);
  if (!channelRecord) {
    throw Object.assign(new Error(`Canal inconnu: ${pivot.channel}`), { status: 400 });
  }

  const client = pivot.explicit_client_id
    ? Store.get('clients', pivot.explicit_client_id)
    : findOrCreateClient({
        channel: pivot.channel,
        identifier: pivot.client_identifier,
        hintName: pivot.client_hint_name,
      });

  if (!client) {
    throw Object.assign(new Error('Client introuvable'), { status: 404 });
  }

  const classification = classify(pivot.raw_content);
  const recentCount = countRecentComplaints(client.client_id);
  const priorityResult = computePriority({
    classification,
    client: { ...client, complaints_last_90_days: recentCount },
    channel: pivot.channel,
  });

  const now = new Date().toISOString();

  const complaint = {
    complaint_id: Store.uuid(),
    client_id: client.client_id,
    channel_id: channelRecord.channel_id,
    category: classification.category,
    description: pivot.raw_content,
    external_reference_id: pivot.external_reference_id || null,
    attachments: pivot.attachments || [],
    metadata: pivot.metadata || {},
    created_at: now,
  };
  Store.insert('complaints', complaint);

  const ticketNumber = generateTicketNumber(new Date(now));
  const sla = computeSlaDueDates(priorityResult.priority, now);

  const ticket = {
    ticket_id: Store.uuid(),
    ticket_number: ticketNumber,
    complaint_id: complaint.complaint_id,
    priority: priorityResult.priority,
    priority_score: priorityResult.score,
    priority_reasons: priorityResult.reasons,
    current_status: 'New',
    team: null, // renseigné après attribution
    sla_first_response_due: sla.sla_first_response_due,
    sla_resolution_due: sla.sla_resolution_due,
    resolved_at: null,
    escalated: false,
    created_at: now,
  };
  Store.insert('tickets', ticket);

  Store.insert('status_history', {
    history_id: Store.uuid(),
    ticket_id: ticket.ticket_id,
    previous_status: null,
    new_status: 'New',
    changed_by: pivot.created_by || null,
    changed_at: now,
    comment: `Ticket créé via le canal "${pivot.channel}".`,
  });

  const assignmentResult = autoAssign(ticket.ticket_id, classification.category);
  if (assignmentResult) {
    Store.update('tickets', ticket.ticket_id, 'ticket_id', { team: assignmentResult.teamName });
  }

  // Notifications simulées : accusé de réception client + alerte agent
  const notifChannel = client.email ? 'email' : client.phone_number ? 'sms' : 'in_app';
  notifications.send(ticket.ticket_id, 'client', client.client_id, notifChannel, 'accuse_reception', {
    ticket_number: ticket.ticket_number,
  });
  if (assignmentResult) {
    notifications.send(
      ticket.ticket_id,
      'agent',
      assignmentResult.agent.user_id,
      'in_app',
      'nouvelle_attribution',
      { ticket_number: ticket.ticket_number, priority: ticket.priority }
    );
  }

  return {
    client,
    complaint,
    ticket: Store.get('tickets', ticket.ticket_id),
    classification,
    priorityResult,
    assignment: assignmentResult,
  };
}

module.exports = { processIncoming, findOrCreateClient, countRecentComplaints };
