// src/routes/complaints.js
const express = require('express');
const Store = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired, requireRole('supervisor', 'admin'));

router.get('/', (req, res) => {
  const complaints = Store.all('complaints').map((c) => {
    const client = Store.get('clients', c.client_id, 'client_id');
    const channel = Store.get('channels', c.channel_id, 'channel_id');
    const ticket = Store.findOne('tickets', (t) => t.complaint_id === c.complaint_id);
    return {
      ...c,
      client_name: client ? client.full_name : null,
      channel_code: channel ? channel.code : null,
      ticket_number: ticket ? ticket.ticket_number : null,
    };
  });
  res.json(complaints.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
});

module.exports = router;
