// src/routes/reports.js
const express = require('express');
const Store = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired, requireRole('supervisor', 'admin'));

function teamNameForUser(user) {
  if (!user.team_id) return null;
  const team = Store.get('teams', user.team_id, 'team_id');
  return team ? team.name : null;
}

router.get('/kpis', (req, res) => {
  const { from, to, channel, category, team } = req.query;
  const fromDate = from ? new Date(from) : new Date(0);
  const toDate = to ? new Date(to) : new Date(8640000000000000);

  let tickets = Store.all('tickets').filter((t) => {
    const created = new Date(t.created_at);
    return created >= fromDate && created <= toDate;
  });

  if (req.user.role === 'supervisor') {
    const scopeTeam = teamNameForUser(req.user);
    tickets = tickets.filter((t) => t.team === scopeTeam);
  } else if (team) {
    tickets = tickets.filter((t) => t.team === team);
  }

  // Jointures pour filtres canal/catégorie
  const complaintsById = new Map(Store.all('complaints').map((c) => [c.complaint_id, c]));
  const channelsById = new Map(Store.all('channels').map((c) => [c.channel_id, c]));

  if (channel || category) {
    tickets = tickets.filter((t) => {
      const c = complaintsById.get(t.complaint_id);
      if (!c) return false;
      if (category && c.category !== category) return false;
      if (channel) {
        const ch = channelsById.get(c.channel_id);
        if (!ch || ch.code !== channel) return false;
      }
      return true;
    });
  }

  const total = tickets.length;
  const closedLike = tickets.filter((t) => t.current_status === 'Resolved' || t.current_status === 'Closed');
  const withResolution = tickets.filter((t) => t.resolved_at);

  const mttrHours = withResolution.length
    ? withResolution.reduce((sum, t) => sum + (new Date(t.resolved_at) - new Date(t.created_at)), 0) /
      withResolution.length /
      (1000 * 60 * 60)
    : null;

  const slaRespected = withResolution.filter((t) => new Date(t.resolved_at) <= new Date(t.sla_resolution_due));
  const slaComplianceRate = withResolution.length ? slaRespected.length / withResolution.length : null;

  const resolutionRate = total ? closedLike.length / total : null;

  const ticketIds = new Set(tickets.map((t) => t.ticket_id));
  const csatEntries = Store.all('csat').filter((c) => ticketIds.has(c.ticket_id));
  const csatAvg = csatEntries.length
    ? csatEntries.reduce((s, c) => s + c.score, 0) / csatEntries.length
    : null;

  const volumeByChannel = {};
  const volumeByStatus = {};
  const volumeByPriority = {};
  const volumeByCategory = {};
  for (const t of tickets) {
    const c = complaintsById.get(t.complaint_id);
    const ch = c ? channelsById.get(c.channel_id) : null;
    const chCode = ch ? ch.code : 'inconnu';
    volumeByChannel[chCode] = (volumeByChannel[chCode] || 0) + 1;
    volumeByStatus[t.current_status] = (volumeByStatus[t.current_status] || 0) + 1;
    volumeByPriority[t.priority] = (volumeByPriority[t.priority] || 0) + 1;
    if (c) volumeByCategory[c.category] = (volumeByCategory[c.category] || 0) + 1;
  }

  res.json({
    total_tickets: total,
    mttr_hours: mttrHours,
    resolution_rate: resolutionRate,
    sla_compliance_rate: slaComplianceRate,
    csat_average: csatAvg,
    csat_responses: csatEntries.length,
    volume_by_channel: volumeByChannel,
    volume_by_status: volumeByStatus,
    volume_by_priority: volumeByPriority,
    volume_by_category: volumeByCategory,
    escalated_count: tickets.filter((t) => t.escalated).length,
  });
});

module.exports = router;
