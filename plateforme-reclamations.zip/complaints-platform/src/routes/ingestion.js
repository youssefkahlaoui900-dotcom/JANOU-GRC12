// src/routes/ingestion.js
// Un endpoint par canal, chacun ne fait que construire l'objet pivot
// normalisé (section 2.6) à partir du format natif du canal, puis délègue
// tout le reste au pipeline Core. Ajouter un canal = ajouter un adaptateur
// ici, sans toucher au moteur de ticketing.

const express = require('express');
const { authRequired, requireRole } = require('../middleware/auth');
const { processIncoming } = require('../services/pipeline');

const router = express.Router();

function respond(res, result) {
  res.status(201).json({
    ticket: result.ticket,
    client: result.client,
    classification: result.classification,
    priority: result.priorityResult,
    assigned_to: result.assignment ? result.assignment.agent.full_name : null,
    team: result.assignment ? result.assignment.teamName : null,
  });
}

function handleErrors(fn) {
  return (req, res) => {
    try {
      fn(req, res);
    } catch (e) {
      res.status(e.status || 500).json({ error: e.message || 'Erreur interne.' });
    }
  };
}

// --- Email (IMAP/Inbound Parse simulé) ---
router.post(
  '/email',
  handleErrors((req, res) => {
    const { from, subject, body, attachments } = req.body || {};
    if (!from || !body) return res.status(400).json({ error: 'Champs requis: from, body.' });
    const result = processIncoming({
      channel: 'email',
      external_reference_id: `email-${Date.now()}`,
      client_identifier: from,
      raw_content: `${subject ? subject + '\n' : ''}${body}`,
      attachments: attachments || [],
      metadata: { subject },
    });
    respond(res, result);
  })
);

// --- Facebook Messenger (webhook Graph API simulé) ---
router.post(
  '/facebook',
  handleErrors((req, res) => {
    const { psid, sender_name, message, attachments } = req.body || {};
    if (!psid || !message) return res.status(400).json({ error: 'Champs requis: psid, message.' });
    const result = processIncoming({
      channel: 'facebook',
      external_reference_id: psid,
      client_identifier: psid,
      client_hint_name: sender_name,
      raw_content: message,
      attachments: attachments || [],
      metadata: { psid },
    });
    respond(res, result);
  })
);

// --- WhatsApp Business (Meta Cloud API / BSP simulé) ---
router.post(
  '/whatsapp',
  handleErrors((req, res) => {
    const { phone, sender_name, message, attachments } = req.body || {};
    if (!phone || !message) return res.status(400).json({ error: 'Champs requis: phone, message.' });
    const result = processIncoming({
      channel: 'whatsapp',
      external_reference_id: `wa-${Date.now()}`,
      client_identifier: phone,
      client_hint_name: sender_name,
      raw_content: message,
      attachments: attachments || [],
      metadata: { phone },
    });
    respond(res, result);
  })
);

// --- Portail Web (client structuré, déjà normalisé nativement) ---
router.post(
  '/web',
  handleErrors((req, res) => {
    const { full_name, email, phone, account_number, category, description, attachments } =
      req.body || {};
    if (!description) return res.status(400).json({ error: 'Champ requis: description.' });
    const identifier = account_number || email || phone || null;
    const result = processIncoming({
      channel: 'web',
      client_identifier: identifier,
      client_hint_name: full_name,
      raw_content: description,
      attachments: attachments || [],
      metadata: { client_selected_category: category || null },
    });
    if (category) result.ticket = result.ticket; // catégorie déjà choisie par le client : conservée en métadonnée
    respond(res, result);
  })
);

// --- Application Mobile (même nature que web, canal distinct pour le KPI) ---
router.post(
  '/mobile_app',
  handleErrors((req, res) => {
    const { full_name, email, phone, account_number, category, description, attachments } =
      req.body || {};
    if (!description) return res.status(400).json({ error: 'Champ requis: description.' });
    const identifier = account_number || email || phone || null;
    const result = processIncoming({
      channel: 'mobile_app',
      client_identifier: identifier,
      client_hint_name: full_name,
      raw_content: description,
      attachments: attachments || [],
      metadata: { client_selected_category: category || null },
    });
    respond(res, result);
  })
);

// --- Centre d'appels (saisie agent, intégration CTI simulée) ---
router.post(
  '/call_center',
  authRequired,
  requireRole('agent', 'supervisor', 'admin'),
  handleErrors((req, res) => {
    const { full_name, email, phone, account_number, summary, caller_number, attachments } =
      req.body || {};
    if (!summary) return res.status(400).json({ error: 'Champ requis: summary.' });
    const identifier = account_number || email || phone || caller_number || null;
    const result = processIncoming({
      channel: 'call_center',
      client_identifier: identifier,
      client_hint_name: full_name,
      raw_content: summary,
      attachments: attachments || [],
      metadata: { caller_number },
      created_by: req.user.user_id,
    });
    respond(res, result);
  })
);

// --- Agence physique (saisie manuelle digitalisée par un conseiller) ---
router.post(
  '/agency',
  authRequired,
  requireRole('agent', 'supervisor', 'admin'),
  handleErrors((req, res) => {
    const { account_number, full_name, email, phone, description, agency_code, attachments } =
      req.body || {};
    if (!description || !agency_code) {
      return res.status(400).json({ error: 'Champs requis: description, agency_code.' });
    }
    const identifier = account_number || email || phone || null;
    const result = processIncoming({
      channel: 'agency',
      client_identifier: identifier,
      client_hint_name: full_name,
      raw_content: description,
      attachments: attachments || [],
      metadata: { agency_code, conseiller_id: req.user.user_id },
      created_by: req.user.user_id,
    });
    respond(res, result);
  })
);

module.exports = router;
