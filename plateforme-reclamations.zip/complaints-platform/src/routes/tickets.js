// src/routes/tickets.js
const express = require('express');
const Store = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');
const { enrichTicket, currentAssignment, ticketHistory, ticketAssignments, ticketNotifications } = require('../services/enrich');
const { reassign } = require('../services/assignment');
const notifications = require('../services/notifications');

const router = express.Router();

const VALID_STATUSES = ['New', 'In Progress', 'Pending', 'Resolved', 'Closed'];

function teamNameForUser(user) {
  if (!user.team_id) return null;
  const team = Store.get('teams', user.team_id, 'team_id');
  return team ? team.name : null;
}

function inScope(req, ticket) {
  if (req.user.role === 'admin') return true;
  if (req.user.role === 'supervisor') {
    return ticket.team === teamNameForUser(req.user);
  }
  // agent
  const assignment = currentAssignment(ticket.ticket_id);
  return assignment && assignment.agent_id === req.user.user_id;
}

router.get('/', authRequired, (req, res) => {
  const { status, priority, channel, q, team } = req.query;
  let tickets = Store.all('tickets').filter((t) => inScope(req, t));

  if (status) tickets = tickets.filter((t) => t.current_status === status);
  if (priority) tickets = tickets.filter((t) => t.priority === priority);
  if (team && req.user.role === 'admin') tickets = tickets.filter((t) => t.team === team);

  let enriched = tickets.map(enrichTicket);

  if (channel) enriched = enriched.filter((t) => t.channel && t.channel.code === channel);
  if (q) {
    const needle = q.toLowerCase();
    enriched = enriched.filter(
      (t) =>
        t.ticket_number.toLowerCase().includes(needle) ||
        (t.complaint && t.complaint.description.toLowerCase().includes(needle)) ||
        (t.client && t.client.full_name && t.client.full_name.toLowerCase().includes(needle))
    );
  }

  enriched.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json(enriched);
});

router.get('/:id', authRequired, (req, res) => {
  const ticket = Store.get('tickets', req.params.id, 'ticket_id');
  if (!ticket) return res.status(404).json({ error: 'Ticket introuvable.' });
  if (!inScope(req, ticket)) return res.status(403).json({ error: 'Hors de votre périmètre.' });
  res.json({
    ...enrichTicket(ticket),
    status_history: ticketHistory(ticket.ticket_id),
    assignments_history: ticketAssignments(ticket.ticket_id).map((a) => {
      const agent = Store.get('users', a.agent_id, 'user_id');
      const by = a.assigned_by ? Store.get('users', a.assigned_by, 'user_id') : null;
      return { ...a, agent_name: agent ? agent.full_name : 'Inconnu', assigned_by_name: by ? by.full_name : 'Système (auto)' };
    }),
    notifications: ticketNotifications(ticket.ticket_id),
  });
});

router.patch('/:id/status', authRequired, (req, res) => {
  const ticket = Store.get('tickets', req.params.id, 'ticket_id');
  if (!ticket) return res.status(404).json({ error: 'Ticket introuvable.' });
  if (!inScope(req, ticket)) return res.status(403).json({ error: 'Hors de votre périmètre.' });

  const { new_status, comment } = req.body || {};
  if (!VALID_STATUSES.includes(new_status)) {
    return res.status(400).json({ error: `Statut invalide. Valeurs possibles: ${VALID_STATUSES.join(', ')}` });
  }
  if (ticket.current_status === 'Closed' && req.user.role !== 'admin') {
    return res.status(400).json({ error: 'Ticket clos : seul un admin peut le réouvrir.' });
  }
  if (new_status === ticket.current_status) {
    return res.status(400).json({ error: 'Le ticket est déjà dans ce statut.' });
  }

  const now = new Date().toISOString();
  const patch = { current_status: new_status };
  if ((new_status === 'Resolved' || new_status === 'Closed') && !ticket.resolved_at) {
    patch.resolved_at = now;
  }
  Store.update('tickets', ticket.ticket_id, 'ticket_id', patch);

  Store.insert('status_history', {
    history_id: Store.uuid(),
    ticket_id: ticket.ticket_id,
    previous_status: ticket.current_status,
    new_status,
    changed_by: req.user.user_id,
    changed_at: now,
    comment: comment || null,
  });

  const complaint = Store.get('complaints', ticket.complaint_id, 'complaint_id');
  const client = complaint ? Store.get('clients', complaint.client_id, 'client_id') : null;
  if (client) {
    const notifChannel = client.email ? 'email' : client.phone_number ? 'sms' : 'in_app';
    notifications.send(ticket.ticket_id, 'client', client.client_id, notifChannel, 'changement_statut', {
      ticket_number: ticket.ticket_number,
      new_status,
    });
  }

  res.json(enrichTicket(Store.get('tickets', ticket.ticket_id, 'ticket_id')));
});

router.post('/:id/reassign', authRequired, requireRole('supervisor', 'admin'), (req, res) => {
  const ticket = Store.get('tickets', req.params.id, 'ticket_id');
  if (!ticket) return res.status(404).json({ error: 'Ticket introuvable.' });
  if (!inScope(req, ticket)) return res.status(403).json({ error: 'Hors de votre périmètre.' });

  const { agent_id, reason } = req.body || {};
  const agent = Store.get('users', agent_id, 'user_id');
  if (!agent || agent.role !== 'agent') {
    return res.status(400).json({ error: 'agent_id doit correspondre à un agent valide.' });
  }
  reassign(ticket.ticket_id, agent_id, req.user.user_id, reason);
  res.json(enrichTicket(Store.get('tickets', ticket.ticket_id, 'ticket_id')));
});

// Intentionnellement public : dans ce prototype, le client n'a pas de
// compte interne authentifié. En production, on protégerait cette route
// par un token CSAT à usage unique envoyé dans la notification de clôture.
router.post('/:id/csat', (req, res) => {
  const ticket = Store.get('tickets', req.params.id, 'ticket_id');
  if (!ticket) return res.status(404).json({ error: 'Ticket introuvable.' });
  const { score, comment } = req.body || {};
  const n = Number(score);
  if (!n || n < 1 || n > 5) return res.status(400).json({ error: 'score doit être entre 1 et 5.' });
  Store.insert('csat', {
    csat_id: Store.uuid(),
    ticket_id: ticket.ticket_id,
    score: n,
    comment: comment || null,
    submitted_at: new Date().toISOString(),
  });
  res.status(201).json({ ok: true });
});

module.exports = router;
