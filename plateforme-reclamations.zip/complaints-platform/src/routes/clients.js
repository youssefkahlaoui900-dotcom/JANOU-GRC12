// src/routes/clients.js
const express = require('express');
const Store = require('../db');
const { authRequired } = require('../middleware/auth');
const { enrichTicket } = require('../services/enrich');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { q } = req.query;
  let clients = Store.all('clients');
  if (q) {
    const needle = q.toLowerCase();
    clients = clients.filter(
      (c) =>
        (c.full_name && c.full_name.toLowerCase().includes(needle)) ||
        (c.email && c.email.toLowerCase().includes(needle)) ||
        (c.phone_number && c.phone_number.includes(needle)) ||
        (c.account_number && c.account_number.toLowerCase().includes(needle))
    );
  }
  res.json(clients.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)));
});

router.get('/:id', (req, res) => {
  const client = Store.get('clients', req.params.id, 'client_id');
  if (!client) return res.status(404).json({ error: 'Client introuvable.' });

  const complaints = Store.find('complaints', (c) => c.client_id === client.client_id);
  const complaintIds = new Set(complaints.map((c) => c.complaint_id));
  const tickets = Store.all('tickets')
    .filter((t) => complaintIds.has(t.complaint_id))
    .map(enrichTicket);

  res.json({ ...client, tickets });
});

module.exports = router;
