// src/routes/users.js
const express = require('express');
const Store = require('../db');
const { authRequired, requireRole } = require('../middleware/auth');
const { activeAssignmentCount } = require('../services/assignment');

const router = express.Router();
router.use(authRequired);

router.get('/', requireRole('supervisor', 'admin'), (req, res) => {
  const users = Store.all('users').map((u) => {
    const team = Store.get('teams', u.team_id, 'team_id');
    return {
      user_id: u.user_id,
      full_name: u.full_name,
      email: u.email,
      role: u.role,
      team: team ? team.name : null,
      is_active: u.is_active,
      active_ticket_count: u.role === 'agent' ? activeAssignmentCount(u.user_id) : null,
    };
  });
  res.json(users);
});

router.get('/teams', (req, res) => {
  res.json(Store.all('teams'));
});

module.exports = router;
