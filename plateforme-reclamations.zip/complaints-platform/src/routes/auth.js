// src/routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const Store = require('../db');
const { signUser, authRequired } = require('../middleware/auth');

const router = express.Router();

router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Email et mot de passe requis.' });
  }
  const user = Store.findOne('users', (u) => u.email.toLowerCase() === String(email).toLowerCase());
  if (!user || !user.is_active || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Identifiants invalides.' });
  }
  const token = signUser(user);
  const team = Store.get('teams', user.team_id, 'team_id');
  res.json({
    token,
    user: {
      user_id: user.user_id,
      full_name: user.full_name,
      email: user.email,
      role: user.role,
      team: team ? team.name : null,
    },
  });
});

router.get('/me', authRequired, (req, res) => {
  const user = Store.get('users', req.user.user_id, 'user_id');
  if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  const team = Store.get('teams', user.team_id, 'team_id');
  res.json({
    user_id: user.user_id,
    full_name: user.full_name,
    email: user.email,
    role: user.role,
    team: team ? team.name : null,
  });
});

module.exports = router;
