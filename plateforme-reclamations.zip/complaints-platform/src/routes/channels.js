// src/routes/channels.js
const express = require('express');
const Store = require('../db');
const { authRequired } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  res.json(Store.all('channels'));
});

module.exports = router;
