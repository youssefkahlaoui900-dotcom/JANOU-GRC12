// src/db.js
// Magasin de données relationnel simplifié, persistant sur disque (JSON).
// Remplace PostgreSQL pour ce prototype afin de fonctionner sans dépendance
// native (aucune compilation requise) tout en respectant fidèlement le
// modèle de données de la spécification (tables, clés étrangères, journaux
// append-only pour Status_History et Assignments).

const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'db.json');

const EMPTY_STATE = {
  teams: [],
  users: [],
  clients: [],
  channels: [],
  complaints: [],
  tickets: [],
  status_history: [],
  assignments: [],
  notifications: [],
  csat: [],
  meta: { ticket_sequences: {} }, // { '2026': 4821 }
};

function load() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(EMPTY_STATE, null, 2));
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    return JSON.parse(JSON.stringify(EMPTY_STATE));
  }
}

let state = load();
let writeScheduled = false;

function persist() {
  // Écriture différée (debounce) pour éviter des écritures disque excessives
  // lors d'opérations en rafale, tout en restant simple/synchrone côté API.
  if (writeScheduled) return;
  writeScheduled = true;
  setImmediate(() => {
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2));
    writeScheduled = false;
  });
}

function uuid() {
  return require('crypto').randomUUID();
}

const Store = {
  uuid,

  reset() {
    state = JSON.parse(JSON.stringify(EMPTY_STATE));
    persist();
  },

  all(table) {
    return state[table] || [];
  },

  get(table, id, idField) {
    const field = idField || `${table.replace(/s$/, '')}_id`;
    return (state[table] || []).find((r) => r[field] === id) || null;
  },

  find(table, predicate) {
    return (state[table] || []).filter(predicate);
  },

  findOne(table, predicate) {
    return (state[table] || []).find(predicate) || null;
  },

  insert(table, record) {
    if (!state[table]) state[table] = [];
    state[table].push(record);
    persist();
    return record;
  },

  update(table, id, idField, patch) {
    const field = idField || `${table.replace(/s$/, '')}_id`;
    const rec = (state[table] || []).find((r) => r[field] === id);
    if (!rec) return null;
    Object.assign(rec, patch);
    persist();
    return rec;
  },

  nextTicketSequence(year) {
    const seqs = state.meta.ticket_sequences;
    const current = seqs[year] || 0;
    const next = current + 1;
    seqs[year] = next;
    persist();
    return next;
  },

  raw() {
    return state;
  },
};

module.exports = Store;
