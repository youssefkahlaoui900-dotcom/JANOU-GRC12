# Plateforme Unifiée de Gestion des Réclamations Clients — Prototype exécutable

Ce projet est une implémentation **fonctionnelle et exécutable en local** de la spécification
technique fournie : ingestion multicanal, classification automatique, calcul de priorité et
de SLA, attribution automatique avec escalade, RBAC à 4 rôles, et tableau de bord KPI.

Il a été conçu pour être lancé **sans aucun service cloud externe** (pas de compte AWS,
Twilio, Meta ou PostgreSQL nécessaire) afin de pouvoir être testé immédiatement.

## Démarrage rapide

Prérequis : [Node.js](https://nodejs.org) version 18 ou plus récente.

```bash
npm install
npm start
```

Puis ouvrez **http://localhost:3000** dans votre navigateur.

Au premier démarrage, la base est automatiquement amorcée avec des équipes, des canaux,
des utilisateurs et quelques clients de démonstration (voir `src/seed.js`).

### Comptes de démonstration

Mot de passe unique pour tous les comptes : **`Demo1234!`**

| Email | Rôle | Équipe |
|---|---|---|
| `admin@demo.local` | Admin | — |
| `superviseur1@demo.local` | Superviseur | Support Général |
| `superviseur2@demo.local` | Superviseur | Technique |
| `agent.facturation@demo.local` | Agent | Facturation |
| `agent.technique@demo.local` | Agent | Technique |
| `agent.livraison@demo.local` | Agent | Livraison |
| `agent.securite@demo.local` | Agent | Sécurité & Fraude |
| `agent.general@demo.local` | Agent | Support Général |

L'écran de connexion propose ces comptes en un clic.

### Réinitialiser les données de démonstration

```bash
npm run reset-data
npm start
```

## Ce qu'il faut tester en premier

1. Connectez-vous en **admin**.
2. Allez dans **Simulateur de canaux** → onglet *Email* → écrivez un message contenant
   « fraude » ou « piraté » → envoyez. Observez la priorité **P1**, l'équipe
   *Sécurité & Fraude* et l'agent assigné automatiquement.
3. Essayez l'onglet *WhatsApp* avec un message de retard de livraison → priorité **P3**,
   équipe *Livraison*.
4. Ouvrez le ticket créé, changez son statut, consultez l'historique des statuts,
   des attributions et des notifications simulées.
5. Reconnectez-vous avec un compte **agent** : le menu *Rapports* et *Équipe* disparaît,
   et la liste des tickets ne montre que les tickets qui lui sont assignés (RBAC vérifié
   à la fois côté interface et côté API).
6. Connectez-vous en **superviseur** ou **admin** pour consulter **Rapports** (MTTR, taux
   de résolution, respect du SLA, CSAT, volumes par canal/catégorie) avec filtres de
   période/canal/catégorie.

L'escalade automatique (section 3.4 de la spécification) tourne en arrière-plan toutes les
30 secondes : tout ticket en statut *Nouveau* dont le SLA de première réponse est dépassé
est automatiquement réattribué à un superviseur.

## Correspondance avec la spécification technique

| Section de la spec | Implémentation dans ce prototype |
|---|---|
| 1. Architecture (monolithe modulaire) | `src/` organisé en modules (routes/services) au sein d'un seul serveur Express — fidèle à la recommandation de démarrer en monolithe modulaire avant extraction. |
| 2. Gestion multicanal | `src/routes/ingestion.js` : un adaptateur par canal (email, web, mobile, call_center, facebook, whatsapp, agency), tous convergeant vers l'objet pivot défini en 2.6, traité uniquement par `src/services/pipeline.js`. |
| 3. Ticketing (statuts, priorité, SLA, attribution) | `src/services/classify.js`, `priority.js`, `sla.js`, `assignment.js`, `escalation.js`. |
| 4. Modèle de données | `src/db.js` reproduit fidèlement les tables et relations de la section 4 (voir note ci-dessous). |
| 5. Sécurité / RBAC | JWT (`src/middleware/auth.js`) + contrôle de périmètre par rôle appliqué à chaque route (`inScope` dans `tickets.js`). |
| 6. KPI / reporting | `src/routes/reports.js` (MTTR, taux de résolution, respect SLA, CSAT, volumes). |
| 7. Stack technologique | Voir tableau de simplifications ci-dessous. |

## Simplifications volontaires de ce prototype

La spécification décrit une architecture cible de production (microservices ciblés, AWS,
Kafka, Twilio, Meta Cloud API, PostgreSQL, React, Flutter...). Pour rester **exécutable
immédiatement sans aucune dépendance externe**, ce prototype fait les choix suivants :

| Domaine | Spécification cible | Ce prototype | Pourquoi |
|---|---|---|---|
| Base de données | PostgreSQL | Magasin JSON persistant maison (`src/db.js`) reproduisant le même schéma relationnel | Aucune compilation native, aucun service à installer ; migration vers PostgreSQL = remplacer ce seul fichier, les routes/services n'en dépendent pas. |
| Message broker | Kafka / RabbitMQ | Appels de fonction synchrones en mémoire | Pas de file de messages nécessaire à l'échelle d'une démo ; la frontière est déjà isolée dans `pipeline.js` si une vraie file doit être ajoutée. |
| Notifications (email/SMS/push) | Amazon SES, Twilio, Firebase | Simulées et journalisées dans la table `notifications` (`src/services/notifications.js`) | Aucun compte fournisseur requis ; l'interface est conçue pour être branchée sur un vrai SDK sans changer les appelants. |
| Frontend web | React + TypeScript | JavaScript natif (sans build) | Le prototype est servi directement par Express, sans étape de compilation, donc utilisable hors-ligne immédiatement après `npm install`. |
| Application mobile | Flutter / React Native | Non fournie (l'interface web est responsive) | Une application mobile native nécessite des outils de build et des stores ; hors périmètre d'un prototype local. |
| Authentification OTP invité | Vérification OTP réelle (SMS/email) | Acceptée sans vérification (client marqué `is_verified: false`) | Aucun fournisseur SMS/email branché dans ce prototype. |
| Webhooks réseaux sociaux | Abonnement réel à l'API Graph / WhatsApp Business | Endpoints équivalents appelés depuis le simulateur intégré | Aucune page Facebook/numéro WhatsApp Business réel n'est nécessaire pour démontrer la logique. |

Tous les noms de champs, le vocabulaire métier (statuts, priorités, catégories) et la
logique de décision (priorisation, routage, SLA, escalade) suivent exactement les règles
de la spécification fournie.

## Structure du projet

```
server.js                     Point d'entrée
src/
  db.js                       Magasin de données (remplace PostgreSQL)
  seed.js                     Amorçage des données de démonstration
  middleware/auth.js          JWT + RBAC
  services/
    classify.js                Catégorisation par mots-clés
    priority.js                Calcul de priorité P1/P2/P3
    sla.js                     Échéances SLA
    assignment.js               Attribution automatique + réassignation
    escalation.js               Escalade automatique SLA dépassé
    notifications.js            Notifications simulées
    pipeline.js                  Orchestrateur central (Service Core)
    ticketNumber.js              Génération TCK-ANNÉE-SÉQUENCE
    enrich.js                    Jointures pour l'API
  routes/                       auth, ingestion, tickets, complaints, clients, channels, users, reports
public/                        Frontend (HTML/CSS/JS natif, sans build)
```

## Limites connues (prototype)

- Le magasin de données n'est pas conçu pour des accès concurrents à très haute échelle
  (écriture fichier en debounce) : adapté à une démo/POC, pas à de la charge de production.
- Pas de file d'attente réelle pour l'ingestion asynchrone à fort volume (section 1.1) :
  les pics de charge ne sont pas amortis comme le ferait Kafka/RabbitMQ.
- La détection de catégorie est un classement par mots-clés, pas un vrai modèle NLP — le
  point d'extension (`src/services/classify.js`) est isolé pour être remplacé facilement.
