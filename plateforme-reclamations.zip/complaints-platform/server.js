// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const { seedIfEmpty, DEMO_PASSWORD } = require('./src/seed');
const { checkSlaEscalations } = require('./src/services/escalation');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '5mb' }));

// --- Routes API ---
app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/ingestion', require('./src/routes/ingestion'));
app.use('/api/tickets', require('./src/routes/tickets'));
app.use('/api/complaints', require('./src/routes/complaints'));
app.use('/api/clients', require('./src/routes/clients'));
app.use('/api/channels', require('./src/routes/channels'));
app.use('/api/users', require('./src/routes/users'));
app.use('/api/reports', require('./src/routes/reports'));

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// --- Frontend statique (SPA) ---
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res, next) => {
  if (req.method !== 'GET' || req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- Amorçage des données de démonstration ---
const wasSeeded = seedIfEmpty();

// --- Boucle d'escalade automatique SLA (section 3.4) ---
// Intervalle volontairement court pour rendre la démonstration visible.
setInterval(() => {
  try {
    checkSlaEscalations();
  } catch (e) {
    console.error('Erreur lors de la vérification SLA :', e.message);
  }
}, 30 * 1000);

app.listen(PORT, () => {
  console.log('---------------------------------------------------------------');
  console.log(' Plateforme Unifiée de Gestion des Réclamations Clients');
  console.log(`  -> http://localhost:${PORT}`);
  if (wasSeeded) {
    console.log('  Données de démonstration créées. Comptes de connexion :');
    console.log(`    admin@demo.local / superviseur1@demo.local / agent.facturation@demo.local ...`);
    console.log(`    Mot de passe (tous les comptes) : ${DEMO_PASSWORD}`);
  }
  console.log('---------------------------------------------------------------');
});
